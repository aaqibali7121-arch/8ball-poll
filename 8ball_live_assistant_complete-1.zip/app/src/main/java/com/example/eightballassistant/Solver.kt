package com.example.eightballassistant
import android.graphics.Bitmap
import kotlin.math.*

data class Pt(val x:Float,val y:Float)
data class Ball(val p:Pt,val r:Float,val white:Boolean,val score:Float)
data class Pocket(val p:Pt,val r:Float,val name:String)
data class Solution(val cue:Pt,val target:Pt,val contact:Pt,val pocket:Pocket,val angle:Float,val power:Int,val risk:String)

object Solver {
 fun solve(src:Bitmap):Solution? {
  val b=src.copy(Bitmap.Config.ARGB_8888,false)
  val table=findTable(b) ?: return null
  val pockets=findPockets(table)
  val balls=findBalls(b,table)
  val cue=balls.filter{it.white}.minByOrNull{it.score} ?: return null
  val targets=balls.filter{it!==cue && !it.white}
  if(targets.isEmpty()) return null
  // Pick the most direct/clear target-pockets combination.
  var best:Pair<Ball,Pocket>?=null; var bestScore=Float.NEGATIVE_INFINITY
  for(t in targets) for(p in pockets){
   val s=scoreShot(cue,t,p)
   if(s>bestScore){bestScore=s;best=t to p}
  }
  val t=best!!.first;p=best.second
  val ux=(t.p.x-p.p.x);val uy=(t.p.y-p.p.y);val len=hypot(ux.toDouble(),uy.toDouble()).toFloat().coerceAtLeast(1f)
  val contact=Pt(t.p.x+ux/len*(2f*t.r),t.p.y+uy/len*(2f*t.r))
  val ang=Math.toDegrees(atan2((contact.y-cue.p.y).toDouble(),(contact.x-cue.p.x).toDouble())).toFloat()
  val dist=hypot((contact.x-cue.p.x).toDouble(),(contact.y-cue.p.y).toDouble()).toFloat()
  val power=(18+dist/10f+dist(hypot((p.p.x-t.p.x).toDouble(),(p.p.y-t.p.y).toDouble()).toFloat())/18f).roundToInt().coerceIn(10,90)
  val risk=if(bestScore>70)"LOW" else if(bestScore>45)"MEDIUM" else "HIGH"
  return Solution(cue.p,t.p,contact,p,ang,power,risk)
 }
 private fun findTable(b:Bitmap):RectF?{
  val w=b.width;val h=b.height;var minX=w;var minY=h;var maxX=0;var maxY=0;var n=0
  val step=6
  for(y in 0 until h step step) for(x in 0 until w step step){
   val c=b.getPixel(x,y);val r=(c shr 16 and 255);val g=(c shr 8 and 255);val bl=c and 255
   if(g>65 && g>r*1.15 && g>bl*1.05 && g-r>18){minX=min(minX,x);minY=min(minY,y);maxX=max(maxX,x);maxY=max(maxY,y);n++}
  }
  return if(n>500 && maxX-minX>w/3) RectF(minX.toFloat(),minY.toFloat(),maxX.toFloat(),maxY.toFloat())
         else RectF(w*.12f,h*.15f,w*.88f,h*.88f)
 }
 private fun findPockets(t:RectF):List<Pocket>{
  val r=((t.width())*.028f).coerceIn(14f,32f);val mx=(t.left+t.right)/2
  return listOf(Pocket(Pt(t.left,t.top),r,"Top-left"),Pocket(Pt(mx,t.top),r,"Top-middle"),Pocket(Pt(t.right,t.top),r,"Top-right"),
   Pocket(Pt(t.left,t.bottom),r,"Bottom-left"),Pocket(Pt(mx,t.bottom),r,"Bottom-middle"),Pocket(Pt(t.right,t.bottom),r,"Bottom-right"))
 }
 private fun findBalls(b:Bitmap,t:RectF):List<Ball>{
  // Fast local-contrast detector. It intentionally favors compact circular regions
  // that differ from the green cloth. Duplicate candidates are merged.
  val raw=ArrayList<Pt>();val step=3
  for(y in (t.top.toInt()+12) until (t.bottom.toInt()-12) step step)
   for(x in (t.left.toInt()+12) until (t.right.toInt()-12) step step){
    val c=b.getPixel(x,y);val r=c shr 16 and 255;val g=c shr 8 and 255;val bl=c and 255
    val bright=(r+g+bl)/3
    var greenNeighbors=0
    for((dx,dy) in arrayOf(-8 to 0,8 to 0,0 to -8,0 to 8)){
     val q=b.getPixel(x+dx,y+dy);val qr=q shr 16 and 255;val qg=q shr 8 and 255;val qb=q and 255
     if(qg>qr*1.12 && qg>qb*1.03) greenNeighbors++
    }
    val colored=max(r,max(g,bl))-min(r,min(g,bl))>35
    if(greenNeighbors>=2 && (bright>165 || colored)) raw.add(Pt(x.toFloat(),y.toFloat()))
   }
  val out=ArrayList<Ball>()
  for(p in raw){
   val near=out.indexOfFirst{hypot((it.p.x-p.x).toDouble(),(it.p.y-p.y).toDouble())<18}
   if(near<0){
    val px=p.x.toInt().coerceIn(0,b.width-1);val py=p.y.toInt().coerceIn(0,b.height-1);val c=b.getPixel(px,py)
    val r=c shr 16 and 255;val g=c shr 8 and 255;val bl=c and 255
    val white=r>180&&g>180&&bl>180
    out.add(Ball(p,11f,white,if(white)0f:1f))
   }
  }
  return out.take(24)
 }
 private fun scoreShot(c:Ball,t:Ball,p:Pocket):Float{
  val cueToTarget=hypot((t.p.x-c.p.x).toDouble(),(t.p.y-c.p.y).toDouble()).toFloat()
  val targetToPocket=hypot((p.p.x-t.p.x).toDouble(),(p.p.y-t.p.y).toDouble()).toFloat()
  val directPenalty=targetToPocket/8f
  return 100f-cueToTarget/10f-directPenalty
 }
 private fun dist(x:Float)=x
}