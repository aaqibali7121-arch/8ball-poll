package com.example.eightballassistant
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity:Activity(){
 private val req=701
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  val status=findViewById<TextView>(R.id.status)
  findViewById<Button>(R.id.startButton).setOnClickListener{
   if(!Settings.canDrawOverlays(this)){status.text="Status: Allow Display over other apps";startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));return@setOnClickListener}
   val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
   startActivityForResult(m.createScreenCaptureIntent(),req)
  }
  findViewById<Button>(R.id.stopButton).setOnClickListener{stopService(Intent(this,CaptureService::class.java));status.text="Status: Stopped"}
 }
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==req&&c==RESULT_OK&&d!=null){
  startForegroundService(Intent(this,CaptureService::class.java).putExtra("resultCode",c).putExtra("captureData",d))
 } }
}