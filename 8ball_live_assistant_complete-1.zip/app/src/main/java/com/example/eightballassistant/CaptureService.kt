package com.example.eightballassistant
import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*

class CaptureService:Service(){
 private var projection:MediaProjection?=null;private var display:VirtualDisplay?=null;private var reader:ImageReader?=null
 private var overlay:GuideOverlay?=null;private var wm:WindowManager?=null
 override fun onCreate(){super.onCreate()
  val ch=NotificationChannel("live","Live analysis",NotificationManager.IMPORTANCE_LOW)
  getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
  startForeground(100,Notification.Builder(this,"live").setContentTitle("8 Ball Live Assistant").setContentText("Analyzing screen").setSmallIcon(android.R.drawable.ic_menu_view).build())
 }
 override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
  val rc=i?.getIntExtra("resultCode",-1)?:return START_NOT_STICKY
  val data=i.getParcelableExtra<Intent>("captureData")?:return START_NOT_STICKY
  setupOverlay();val dm=resources.displayMetrics
  val mpm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection=mpm.getMediaProjection(rc,data)
  reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2)
  display=projection!!.createVirtualDisplay("8Ball",dm.widthPixels,dm.heightPixels,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
  reader!!.setOnImageAvailableListener({r->val im=r.acquireLatestImage()?:return@setOnImageAvailableListener
   try{
    // Convert only the active crop to Bitmap for the solver.
    val plane=im.planes[0];val buf=plane.buffer;val row=plane.rowStride;val px=plane.pixelStride
    val w=im.width;val h=im.height;val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
    bmp.copyPixelsFromBuffer(buf)
    val sol=Solver.solve(bmp)
    overlay?.setSolution(sol,w.toFloat(),h.toFloat())
   }catch(_:Throwable){}finally{im.close()}
  },Handler(Looper.getMainLooper()))
  return START_STICKY
 }
 private fun setupOverlay(){val dm=resources.displayMetrics;wm=getSystemService(WINDOW_SERVICE) as WindowManager;overlay=GuideOverlay(this)
  val lp=WindowManager.LayoutParams(dm.widthPixels,dm.heightPixels,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
  wm!!.addView(overlay,lp)
 }
 override fun onDestroy(){reader?.close();display?.release();projection?.stop();overlay?.let{try{wm?.removeView(it)}catch(_:Exception){}};super.onDestroy()}
 override fun onBind(i:Intent?)=null

 class GuideOverlay(c:Context):View(c){
  private val p=Paint(3);private var sol:Solution?=null
  fun setSolution(s:Solution?,w:Float,h:Float){sol=s;postInvalidate()}
  override fun onDraw(c:Canvas){
   super.onDraw(c);val s=sol?:return
   p.style=Paint.Style.STROKE;p.strokeWidth=5f;p.color=Color.rgb(70,235,175);p.pathEffect=DashPathEffect(floatArrayOf(18f,12f),0f)
   c.drawLine(s.cue.x,s.cue.y,s.contact.x,s.contact.y,p)
   p.color=Color.rgb(255,211,92);p.pathEffect=DashPathEffect(floatArrayOf(12f,10f),0f)
   c.drawLine(s.target.x,s.target.y,s.pocket.p.x,s.pocket.p.y,p)
   p.pathEffect=null;p.style=Paint.Style.FILL;p.color=Color.WHITE;p.textSize=32f;p.typeface=Typeface.DEFAULT_BOLD
   c.drawText("${s.pocket.name} • ${s.power}% • ${s.risk}",30f,65f,p)
  }
 }
}